package com.example.mytablayout

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.Menu
import com.example.mytablayout.databinding.ActivityMainBinding
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Menggunakan 'binding' untuk mengatur tampilan dalam aktivitas menggunakan View Binding.
        with(binding) {
            viewPager.adapter = TabAdapter(this@MainActivity)
            TabLayoutMediator(tabLayout, viewPager) { tab, position ->
                tab.text = when (position) {
                    0 -> "Register"
                    1 -> "Login"
                    else -> ""
                }
            }.attach()
        }
    }

            // Override metode onCreateOptionsMenu untuk menambahkan menu ke aktivitas.
            override fun onCreateOptionsMenu(menu: Menu?): Boolean {
                // Menginflasi menu_options.xml ke dalam menu aktivitas.
                menuInflater.inflate(R.menu.menu_options, menu)
                return true
            }
        }
